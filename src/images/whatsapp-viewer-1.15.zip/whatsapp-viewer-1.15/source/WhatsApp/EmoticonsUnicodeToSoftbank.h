#pragma once

#include <map>

extern std::map<int, int> emoticonsUnicodeToSoftbank;
