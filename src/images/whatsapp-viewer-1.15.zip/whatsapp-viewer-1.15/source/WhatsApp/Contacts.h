#pragma once

class Settings;

void importContacts(Settings &settings, const std::string &wadbFilename);
