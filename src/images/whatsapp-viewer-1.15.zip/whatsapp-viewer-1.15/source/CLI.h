#pragma once

#include <vector>

bool handleCommandLineArguments(const std::vector<std::string *> arguments);
