#pragma once

#include <string>

bool saveFileDialog(HWND window, const std::string &suggestion, const std::string &filter, std::string &filename);
