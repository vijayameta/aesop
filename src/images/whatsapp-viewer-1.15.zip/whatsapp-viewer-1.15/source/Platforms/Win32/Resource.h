#pragma once

void loadResource(const WCHAR *name, const WCHAR *type, unsigned char *&bytes, DWORD &size);
