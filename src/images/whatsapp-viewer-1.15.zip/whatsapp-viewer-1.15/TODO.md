# Todo

* Bug: Some smilies doesn't work with newest WhatsApp version
* Rework UI
	* File open dialog
	* Import Contacts (wa.db)
	* Export
* Search messages
* Own Win32 control for chat messages
	* Select single chat message
	* Copy single chat message to clipboard
* VCard support
* Render smilies on same line as text
* Media browser
* Google Contact API to replace numbers by real names
